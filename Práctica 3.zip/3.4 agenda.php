<?php
$nombre = $_POST['nombre'];
$tel = $_POST['tel'];
$trab = $_POST['trabajo'];
$dir = $_POST['dir'];
$ext = $_POST['ext'];

    $archivo = 'contactos.txt';
    if (!file_exists($archivo)) {
        fopen($archivo, 'w');
    }

    $file = fopen($archivo, 'a');
    fwrite($file, "Contacto: $nombre $trab $tel $dir $ext" . PHP_EOL);
    fclose($file);

?>