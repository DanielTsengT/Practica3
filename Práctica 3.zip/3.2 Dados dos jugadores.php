<html>
<head>
</head>
<body>
<?php

$j1 = 0;
$j2 = 0;
print "<h2>Jugador 1</h2><br>";
for ($i = 0; $i < 5; $i++ ) {
    $dado = rand(1,6);
    print "<img src='./img/$dado.jpg' width=100 height=100>\n";
    $j1 = $j1 + $dado;
}

print "<br>";
print "<h2>Jugador 2</h2><br>";
for ($i = 0; $i < 5; $i++ ) {
    $dado = rand(1,6);
    print "<img src='./img/$dado.jpg' width=100 height=100>\n";
    $j2 = $j2 + $dado;
}

if ($j1>$j2) {
    print "<p>Ha ganado el jugador 1</p>";
    print "$j1";
}else {
    print "<p>Ha ganado el jugador 2</p>";
    print "$j2";
}

?>
</body>
</html>