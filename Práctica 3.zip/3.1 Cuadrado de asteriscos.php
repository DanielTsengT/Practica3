<html>
<head>
</head>
<body>
<?php

$alto = $_POST['alto'];
$ancho = $_POST['ancho'];

print "Alto: $alto <br>";
print "Ancho: $ancho <br>";

for ($i = 0; $i < $alto; $i++ ) {
    print"<br>";
    
    for ($a = 0; $a < $ancho; $a++ ) {
        print "*";
    }
}

?>
</body>
</html>