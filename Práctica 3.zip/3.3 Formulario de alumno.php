<?php
$nombre = $_POST['nombre'];
$ensen = $_POST['ensen'];
$tel = $_POST['tel'];
$matr = isset($_POST['matr']) ? '' : 'no';
$most = $_POST['mostrar'];

if ($most == "a"){
    print "El alumno $nombre, con teléfono $tel, $matr está matriculado en $ensen";
}
if($most == "b"){
    $archivo = 'Alumno.txt';
    if (!file_exists($archivo)) {
        fopen($archivo, 'w');
    }

    $file = fopen($archivo, 'a');
    fwrite($file, "El alumno $nombre, con teléfono $tel, $matr está matriculado en $ensen" . PHP_EOL);
    fclose($file);
}
?>