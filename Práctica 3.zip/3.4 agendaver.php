<?php
$nombreArchivo = "contactos.txt";
$fd = fopen($nombreArchivo, "r");
echo "Contactos <br>";

while(!feof($fd)){
    $lectura = fgets($fd);
    echo $lectura."<br>";
}

fclose($fd);
?>