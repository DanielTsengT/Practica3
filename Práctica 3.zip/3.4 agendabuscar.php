<?php
$nombre = $_POST['nombre'];
$nombreArchivo = "contactos.txt";
$fd = fopen($nombreArchivo, "r");
$encontrado = false;

while(!feof($fd)){
    $lectura = fgets($fd);
    if(strpos($lectura, "Contacto: $nombre") !== false) {
   echo "Se ha encontrado a $nombre en $lectura";
   $encontrado = true;
}
}

fclose($file);

if(!$encontrado){
    echo "No se ha encontrado $nombre";
}
?>